from django.apps import AppConfig


class ProductCatalogConfig(AppConfig):
    name = 'product_catalog'
